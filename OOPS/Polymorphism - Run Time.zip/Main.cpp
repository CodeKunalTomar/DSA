#include <iostream>
using namespace std;


int test(int a, int b) {

}

int test(int a) {

}

int test() {

}

int main() {

}

