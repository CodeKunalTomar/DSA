class Vehicle {
	public :
		string color;

		/*
	virtual void print() {
		cout << "Vehicle" << endl;
	}*/


};

