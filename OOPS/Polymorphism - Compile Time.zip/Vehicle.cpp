class Vehicle {
	public :
		string color;

	void print() {
		cout << "Vehicle" << endl;
	}


};

