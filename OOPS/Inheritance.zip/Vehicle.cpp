class Vehicle {
	private :
		int maxSpeed;

	protected :
		int numTyres;

	public :
		string color;

};
