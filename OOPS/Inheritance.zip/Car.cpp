class Car : public Vehicle {
	public :
		int numGears;


		void print() {
			cout << "NumTyres : " << numTyres << endl;
			cout << "Color : " << color << endl;
			cout << "Num gears : " << numGears << endl;
	//		cout << "Max Speed : " << maxSpeed << endl;
		}


};
