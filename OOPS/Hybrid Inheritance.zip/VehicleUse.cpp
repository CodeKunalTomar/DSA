#include <iostream>
using namespace std;
#include "Vehicle.cpp"
#include "Car.cpp"
#include "Truck.cpp"

int main() {
	
}

