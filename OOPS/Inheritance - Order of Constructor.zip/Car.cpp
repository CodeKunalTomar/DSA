class Car : public Vehicle {
	public :
		int numGears;

		//Below is the syntax to call parametrized constructor
		//If we don't call and use Car(), it will call vehicle default construcor implicitly and so on and the heirarchy will continue 
		Car(int x, int y) : Vehicle(x) {
			cout << "Car's constructor " << endl;
			numGears = y;
		}

		~Car() {
			cout << "Car's Destructor " << endl;
		}


		void print() {
			cout << "NumTyres : " << numTyres << endl;
			cout << "Color : " << color << endl;
			cout << "Num gears : " << numGears << endl;
			//		cout << "Max Speed : " << maxSpeed << endl;
		}



};
