class Student {
	public :

		string name;

		void print() {
			cout << "Student " << endl;
		}
};
