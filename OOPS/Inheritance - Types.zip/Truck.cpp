class Truck : public Vehicle {

};
