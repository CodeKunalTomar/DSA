#include <iostream>
using namespace std;
#include "Student.cpp"
#include "Teacher.cpp"
#include "TA.cpp"


int main() {
	TA a;

//	a.Student :: print();

	a.print();

	
	a.Teacher :: name = "abcd";

}

