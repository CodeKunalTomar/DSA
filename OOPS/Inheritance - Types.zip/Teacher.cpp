class Teacher {
	public : 
		string name;
		string age;

		void print() {
			cout << "Teacher" << endl;
		}
};
