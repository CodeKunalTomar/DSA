class TA : public Teacher, public Student {

	public :
		void print() {
			cout << "TA " << endl;
		}
};
